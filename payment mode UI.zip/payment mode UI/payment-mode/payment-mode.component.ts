// payment-mode1.component.ts
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormArray, FormControl } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { PaymentConfigService } from './payment-config.service';

interface Merchant {
  id: string;
  name: string;
}

interface ConfigField {
  id: string;
  label: string;
  type: 'checkbox' | 'radio' | 'select' | 'text' | 'info';
  options?: FieldOption[];
  displayType?: 'grid' | 'list'; // For different layouts
  gridColumns?: number; // Number of columns for grid layout
  required?: boolean;
  infoText?: string; // For info type fields
}

interface FieldOption {
  value: string;
  label: string;
  isFrequent?: boolean; // For categorizing options like frequent banks
}

interface PaymentModeConfig {
  paymentMode: string;
  sections: ConfigSection[];
}

interface ConfigSection {
  id: string;
  title: string;
  fields: ConfigField[];
}

@Component({
  selector: 'app-payment-mode',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './payment-mode.component.html',
  styleUrls: ['./payment-mode.component.scss']
})
export class PaymentModeComponent implements OnInit {
  paymentForm: FormGroup;
  merchants: Merchant[] = [];
  paymentModes: string[] = [];
  currentPaymentConfig: PaymentModeConfig | null = null;

  constructor(
    private fb: FormBuilder,
    private paymentConfigService: PaymentConfigService
  ) {
    this.paymentForm = this.fb.group({
      merchantId: [''],
      paymentMode: [''],
      dynamicFields: this.fb.group({}) // Will hold all dynamic fields
    });
  }

  ngOnInit(): void {
    this.loadMerchants();
    this.loadPaymentModes();

    // Listen to payment mode changes
    this.paymentForm.get('paymentMode')?.valueChanges.subscribe((paymentMode) => {
      if (paymentMode) {
        this.loadPaymentModeConfig(paymentMode);
      } else {
        this.currentPaymentConfig = null;
        this.resetDynamicForm();
      }
    });
  }

  // Load merchants from API
  loadMerchants(): void {
    this.paymentConfigService.getMerchants().subscribe({
      next: (merchants) => {
        this.merchants = merchants;
      },
      error: (error) => {
        console.error('Error loading merchants:', error);
        this.merchants = [
          { id: 'M001', name: 'Merchant 001' },
          { id: 'M002', name: 'Merchant 002' },
          { id: 'M003', name: 'Merchant 003' },
          { id: 'M004', name: 'Merchant 004' },
          { id: 'M005', name: 'Merchant 005' }
        ];
      }
    });
  }

  // Load available payment modes from API
  loadPaymentModes(): void {
    this.paymentConfigService.getPaymentModes().subscribe({
      next: (modes) => {
        this.paymentModes = modes;
      },
      error: (error) => {
        console.error('Error loading payment modes:', error);
        this.paymentModes = ['Card', 'UPI', 'Net Banking', 'EMI', 'FT', 'Wallet'];
      }
    });
  }

  // Load configuration for selected payment mode from API
  loadPaymentModeConfig(paymentMode: string): void {
    this.paymentConfigService.getPaymentModeConfig(paymentMode).subscribe({
      next: (config) => {
        this.currentPaymentConfig = config;
        this.buildDynamicForm(config);

        const merchantId = this.paymentForm.get('merchantId')?.value;
        if (merchantId) {
          this.loadSavedConfiguration(merchantId, paymentMode);
        }
      },
      error: (error) => {
        console.error('Error loading payment mode config:', error);
        const config = this.getMockPaymentModeConfig(paymentMode);
        this.currentPaymentConfig = config;
        this.buildDynamicForm(config);
      }
    });
  }

  // Load previously saved configuration
  loadSavedConfiguration(merchantId: string, paymentMode: string): void {
    this.paymentConfigService.getSavedConfiguration(merchantId, paymentMode).subscribe({
      next: (savedConfig) => {
        console.log('Loaded saved configuration:', savedConfig);
        if (savedConfig && savedConfig.config) {
          this.paymentForm.patchValue({
            dynamicFields: savedConfig.config
          });
          console.log('✅ Loaded saved configuration');
        }
      },
      error: (error) => {
        console.log('No saved configuration found or error:', error);
      }
    });
  }

  // Build dynamic form based on configuration
  buildDynamicForm(config: PaymentModeConfig): void {
    this.resetDynamicForm();
    const dynamicFieldsGroup = this.paymentForm.get('dynamicFields') as FormGroup;

    config.sections.forEach(section => {
      section.fields.forEach(field => {
        if (field.type === 'checkbox') {
          dynamicFieldsGroup.addControl(field.id, this.fb.array([]));

          if (field.options && field.options.length > 5) {
            dynamicFieldsGroup.addControl(`${field.id}_selectAll`, this.fb.control(false));

            dynamicFieldsGroup.get(`${field.id}_selectAll`)?.valueChanges.subscribe(selectAll => {
              this.toggleAllOptions(field.id, selectAll, field.options || []);
            });
          }
        } else if (field.type === 'select' || field.type === 'radio') {
          dynamicFieldsGroup.addControl(field.id, this.fb.control(''));
        } else if (field.type === 'text') {
          dynamicFieldsGroup.addControl(field.id, this.fb.control(''));
        }
      });
    });
  }

  // Reset dynamic form
  resetDynamicForm(): void {
    const dynamicFieldsGroup = this.paymentForm.get('dynamicFields') as FormGroup;
    Object.keys(dynamicFieldsGroup.controls).forEach(key => {
      dynamicFieldsGroup.removeControl(key);
    });
  }

  // Get FormArray for a field
  getFieldArray(fieldId: string): FormArray {
    const dynamicFields = this.paymentForm.get('dynamicFields') as FormGroup;
    return dynamicFields.get(fieldId) as FormArray;
  }

  // Check if an option is selected in a checkbox group
  isOptionSelected(fieldId: string, optionValue: string): boolean {
    const fieldArray = this.getFieldArray(fieldId);
    return fieldArray.controls.some(ctrl => ctrl.value === optionValue);
  }

  // Handle checkbox change
  onCheckboxChange(fieldId: string, optionValue: string, event: any): void {
    const fieldArray = this.getFieldArray(fieldId);

    if (event.target.checked) {
      fieldArray.push(new FormControl(optionValue));
    } else {
      const index = fieldArray.controls.findIndex(ctrl => ctrl.value === optionValue);
      if (index !== -1) {
        fieldArray.removeAt(index);
      }

      const dynamicFields = this.paymentForm.get('dynamicFields') as FormGroup;
      const selectAllControl = dynamicFields.get(`${fieldId}_selectAll`);
      if (selectAllControl) {
        selectAllControl.setValue(false, { emitEvent: false });
      }
    }
  }

  // Toggle all options for a checkbox field
  toggleAllOptions(fieldId: string, selectAll: boolean, options: FieldOption[]): void {
    const fieldArray = this.getFieldArray(fieldId);
    fieldArray.clear();

    if (selectAll) {
      options.forEach(option => {
        fieldArray.push(new FormControl(option.value));
      });
    }
  }

  // Get frequent options (for special display)
  getFrequentOptions(field: ConfigField): FieldOption[] {
    return field.options?.filter(opt => opt.isFrequent) || [];
  }

  // Get other options (non-frequent)
  getOtherOptions(field: ConfigField): FieldOption[] {
    return field.options?.filter(opt => !opt.isFrequent) || [];
  }

  // Check if field has select all option
  hasSelectAllOption(field: ConfigField): boolean {
    const dynamicFields = this.paymentForm.get('dynamicFields') as FormGroup;
    return dynamicFields.get(`${field.id}_selectAll`) !== null;
  }

  // Get grid column class based on configuration
  getGridColumnClass(field: ConfigField): string {
    const columns = field.gridColumns || 5;
    return `grid-cols-${columns}`;
  }

  // Check if payment mode is selected
  get isPaymentModeSelected(): boolean {
    return !!this.paymentForm.get('paymentMode')?.value;
  }

  // Save configuration
  onSave(): void {
    const merchantId = this.paymentForm.get('merchantId')?.value;
    const paymentMode = this.paymentForm.get('paymentMode')?.value;

    if (!merchantId || !paymentMode) {
      alert('Please select both Merchant ID and Payment Mode');
      return;
    }

    const configuration = {
      merchantId,
      paymentMode,
      config: this.paymentForm.get('dynamicFields')?.value
    };

    console.log('💾 Saving Configuration:', configuration);
    localStorage.setItem(`${merchantId}_${paymentMode}`, JSON.stringify(configuration));

    // this.paymentConfigService.saveConfiguration(configuration).subscribe({
    //   next: (response) => {
    //     if (response.success) {
    //       alert(response.message || 'Configuration saved successfully!');
    //       console.log('Configuration ID:', response.configurationId);
    //     } else {
    //       alert('Error: ' + response.message);
    //     }
    //   },
    //   error: (error) => {
    //     console.error('Error saving configuration:', error);
    //     alert('Error saving configuration. Please try again.');
    //   }
    // });
  }

  // Reset form
  onReset(): void {
    if (!this.currentPaymentConfig) {
      return;
    }

    this.buildDynamicForm(this.currentPaymentConfig);
    console.log('🔄 Form has been reset');
  }

  // Mock configuration data (Replace with actual API call)
  getMockPaymentModeConfig(paymentMode: string): PaymentModeConfig {
    const configs: { [key: string]: PaymentModeConfig } = {
      'Card': {
        paymentMode: 'Card',
        sections: [
          {
            id: 'card_config',
            title: 'Card Configuration',
            fields: [
              {
                id: 'cardSubPaymentModes',
                label: 'Select Sub Payment Mode',
                type: 'checkbox',
                options: [
                  { value: 'debit', label: 'Debit Card' },
                  { value: 'credit', label: 'Credit Card' },
                  { value: 'prepaid', label: 'Prepaid Card' }
                ]
              },
              {
                id: 'cardRegions',
                label: 'Select Region',
                type: 'checkbox',
                options: [
                  { value: 'domestic', label: 'Domestic' },
                  { value: 'international', label: 'International' }
                ]
              },
              {
                id: 'cardProductTypes',
                label: 'Select Product Type',
                type: 'checkbox',
                options: [
                  { value: 'standard', label: 'Standard' },
                  { value: 'premium', label: 'Premium' },
                  { value: 'corporate', label: 'Corporate' },
                  { value: 'super_premium', label: 'Super Premium' }
                ]
              }
            ]
          }
        ]
      },
      'UPI': {
        paymentMode: 'UPI',
        sections: [
          {
            id: 'upi_config',
            title: 'UPI Configuration',
            fields: [
              {
                id: 'upiSubModes',
                label: 'Select Sub Payment Mode',
                type: 'checkbox',
                options: [
                  { value: 'savings', label: 'Savings' },
                  { value: 'credit', label: 'Credit' }
                ]
              },
              {
                id: 'upiTypes',
                label: 'Select Type',
                type: 'checkbox',
                options: [
                  { value: 'collect', label: 'Collect' },
                  { value: 'qr', label: 'QR' },
                  { value: 'intent', label: 'Intent' }
                ]
              }
            ]
          }
        ]
      },
      'Net Banking': {
        paymentMode: 'Net Banking',
        sections: [
          {
            id: 'netbanking_config',
            title: 'Net Banking Configuration',
            fields: [
              {
                id: 'selectedBanks',
                label: 'Select Banks',
                type: 'checkbox',
                displayType: 'grid',
                gridColumns: 5,
                options: [
                  { value: 'B001', label: 'State Bank of India', isFrequent: true },
                  { value: 'B002', label: 'HDFC Bank', isFrequent: true },
                  { value: 'B003', label: 'ICICI Bank', isFrequent: true },
                  { value: 'B004', label: 'Axis Bank', isFrequent: true },
                  { value: 'B005', label: 'Kotak Mahindra Bank', isFrequent: true },
                  { value: 'B006', label: 'Punjab National Bank', isFrequent: true },
                  { value: 'B007', label: 'Bank of Baroda', isFrequent: true },
                  { value: 'B008', label: 'Canara Bank', isFrequent: true },
                  { value: 'B009', label: 'IDBI Bank', isFrequent: true },
                  { value: 'B010', label: 'Yes Bank', isFrequent: true },
                  { value: 'B011', label: 'IndusInd Bank', isFrequent: false },
                  { value: 'B012', label: 'Federal Bank', isFrequent: false },
                  { value: 'B013', label: 'IDFC First Bank', isFrequent: false },
                  { value: 'B014', label: 'RBL Bank', isFrequent: false },
                  { value: 'B015', label: 'Bank of India', isFrequent: false }
                ]
              }
            ]
          }
        ]
      },
      'EMI': {
        paymentMode: 'EMI',
        sections: [
          {
            id: 'emi_config',
            title: 'EMI Configuration',
            fields: [
              {
                id: 'emiPaymentModes',
                label: 'Select Payment Mode',
                type: 'checkbox',
                options: [
                  { value: 'debit', label: 'Debit Card' },
                  { value: 'credit', label: 'Credit Card' }
                ]
              }
            ]
          }
        ]
      },
      'FT': {
        paymentMode: 'FT',
        sections: [
          {
            id: 'ft_config',
            title: 'FT Configuration',
            fields: [
              {
                id: 'ft_info',
                label: '',
                type: 'info',
                infoText: 'No additional configuration required for FT payment mode.'
              }
            ]
          }
        ]
      },
      'Wallet': {
        paymentMode: 'Wallet',
        sections: [
          {
            id: 'wallet_config',
            title: 'Wallet Configuration',
            fields: [
              {
                id: 'walletProviders',
                label: 'Select Wallet Providers',
                type: 'checkbox',
                options: [
                  { value: 'paytm', label: 'Paytm' },
                  { value: 'phonepe', label: 'PhonePe' },
                  { value: 'gpay', label: 'Google Pay' },
                  { value: 'amazonpay', label: 'Amazon Pay' },
                  { value: 'mobikwik', label: 'Mobikwik' }
                ]
              }
            ]
          }
        ]
      }
    };

    return configs[paymentMode] || { paymentMode, sections: [] };
  }
}
