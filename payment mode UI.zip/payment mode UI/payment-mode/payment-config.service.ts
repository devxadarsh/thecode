// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class PaymentConfigService {

//   constructor() { }
// }


// payment-config.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

export interface Merchant {
  id: string;
  name: string;
}

export interface ConfigField {
  id: string;
  label: string;
  type: 'checkbox' | 'radio' | 'select' | 'text' | 'info';
  options?: FieldOption[];
  displayType?: 'grid' | 'list';
  gridColumns?: number;
  required?: boolean;
  infoText?: string;
}

export interface FieldOption {
  value: string;
  label: string;
  isFrequent?: boolean;
}

export interface PaymentModeConfig {
  paymentMode: string;
  sections: ConfigSection[];
}

export interface ConfigSection {
  id: string;
  title: string;
  fields: ConfigField[];
}

export interface SaveConfigurationRequest {
  merchantId: string;
  paymentMode: string;
  config: any;
}

export interface SaveConfigurationResponse {
  success: boolean;
  message: string;
  configurationId?: string;
}

@Injectable({
  providedIn: 'root'
})
export class PaymentConfigService {
  private apiBaseUrl = '/api'; // Change this to your actual API base URL

  constructor(private http: HttpClient) { }

  /**
   * Get list of all merchants
   */
  getMerchants(): Observable<Merchant[]> {
    return this.http.get<Merchant[]>(`${this.apiBaseUrl}/merchants`);
  }

  /**
   * Get list of available payment modes
   */
  getPaymentModes(): Observable<string[]> {
    return this.http.get<string[]>(`${this.apiBaseUrl}/payment-modes`);
  }

  /**
   * Get configuration schema for a specific payment mode
   * This returns the dynamic structure (sections, fields, options) for the payment mode
   */
  getPaymentModeConfigEdit(paymentMode: string): Observable<PaymentModeConfig> {
    // return this.http.get<PaymentModeConfig>(
    //   `${this.apiBaseUrl}/payment-mode-config/${paymentMode}`
    // );
    const configs: { [key: string]: PaymentModeConfig } = {
      'Card': {
        paymentMode: 'Card',
        sections: [
          {
            id: 'card_config',
            title: 'Card Configuration',
            fields: [
              {
                id: 'cardSubPaymentModes',
                label: 'Select Sub Payment Mode',
                type: 'checkbox',
                options: [
                  { value: 'debit', label: 'Debit Card' },
                  { value: 'credit', label: 'Credit Card' },
                  { value: 'prepaid', label: 'Prepaid Card' }
                ]
              },
              {
                id: 'cardRegions',
                label: 'Select Region',
                type: 'checkbox',
                options: [
                  { value: 'domestic', label: 'Domestic' },
                  { value: 'international', label: 'International' }
                ]
              },
              {
                id: 'cardProductTypes',
                label: 'Select Product Type',
                type: 'checkbox',
                options: [
                  { value: 'standard', label: 'Standard' },
                  { value: 'premium', label: 'Premium' },
                  { value: 'corporate', label: 'Corporate' },
                  { value: 'super_premium', label: 'Super Premium' }
                ]
              }
            ]
          }
        ]
      },
      'UPI': {
        paymentMode: 'UPI',
        sections: [
          {
            id: 'upi_config',
            title: 'UPI Configuration',
            fields: [
              {
                id: 'upiSubModes',
                label: 'Select Sub Payment Mode',
                type: 'checkbox',
                options: [
                  { value: 'savings', label: 'Savings' },
                  { value: 'credit', label: 'Credit' }
                ]
              },
              {
                id: 'upiTypes',
                label: 'Select Type',
                type: 'checkbox',
                options: [
                  { value: 'collect', label: 'Collect' },
                  { value: 'qr', label: 'QR' },
                  { value: 'intent', label: 'Intent' }
                ]
              }
            ]
          }
        ]
      },
      'Net Banking': {
        paymentMode: 'Net Banking',
        sections: [
          {
            id: 'netbanking_config',
            title: 'Net Banking Configuration',
            fields: [
              {
                id: 'selectedBanks',
                label: 'Select Banks',
                type: 'checkbox',
                displayType: 'grid',
                gridColumns: 5,
                options: [
                  { value: 'B001', label: 'State Bank of India', isFrequent: true },
                  { value: 'B002', label: 'HDFC Bank', isFrequent: true },
                  { value: 'B003', label: 'ICICI Bank', isFrequent: true },
                  { value: 'B004', label: 'Axis Bank', isFrequent: true },
                  { value: 'B005', label: 'Kotak Mahindra Bank', isFrequent: true },
                  { value: 'B006', label: 'Punjab National Bank', isFrequent: true },
                  { value: 'B007', label: 'Bank of Baroda', isFrequent: true },
                  { value: 'B008', label: 'Canara Bank', isFrequent: true },
                  { value: 'B009', label: 'IDBI Bank', isFrequent: true },
                  { value: 'B010', label: 'Yes Bank', isFrequent: true },
                  { value: 'B011', label: 'IndusInd Bank', isFrequent: false },
                  { value: 'B012', label: 'Federal Bank', isFrequent: false },
                  { value: 'B013', label: 'IDFC First Bank', isFrequent: false },
                  { value: 'B014', label: 'RBL Bank', isFrequent: false },
                  { value: 'B015', label: 'Bank of India', isFrequent: false }
                ]
              }
            ]
          }
        ]
      },
      'EMI': {
        paymentMode: 'EMI',
        sections: [
          {
            id: 'emi_config',
            title: 'EMI Configuration',
            fields: [
              {
                id: 'emiPaymentModes',
                label: 'Select Payment Mode',
                type: 'checkbox',
                options: [
                  { value: 'debit', label: 'Debit Card' },
                  { value: 'credit', label: 'Credit Card' }
                ]
              }
            ]
          }
        ]
      },
      'FT': {
        paymentMode: 'FT',
        sections: [
          {
            id: 'ft_config',
            title: 'FT Configuration',
            fields: [
              {
                id: 'ft_info',
                label: '',
                type: 'info',
                infoText: 'No additional configuration required for FT payment mode.'
              }
            ]
          }
        ]
      },
      'Wallet': {
        paymentMode: 'Wallet',
        sections: [
          {
            id: 'wallet_config',
            title: 'Wallet Configuration',
            fields: [
              {
                id: 'walletProviders',
                label: 'Select Wallet Providers',
                type: 'checkbox',
                options: [
                  { value: 'paytm', label: 'Paytm' },
                  { value: 'phonepe', label: 'PhonePe' },
                  { value: 'gpay', label: 'Google Pay' },
                  { value: 'amazonpay', label: 'Amazon Pay' },
                  { value: 'mobikwik', label: 'Mobikwik' }
                ]
              }
            ]
          }
        ]
      }
    };

    // return configs[paymentMode] || { paymentMode, sections: [] };
    return new Observable<PaymentModeConfig>(observer => {
      observer.next(configs[paymentMode] || { paymentMode, sections: [] });
      observer.complete();
    });
  }

  /**
   * Get configuration schema for a specific payment mode
   * This returns the dynamic structure (sections, fields, options) for the payment mode
   */
  getPaymentModeConfig(paymentMode: string): Observable<PaymentModeConfig> {
    // return this.http.get<PaymentModeConfig>(
    //   `${this.apiBaseUrl}/payment-mode-config/${paymentMode}`
    // );
    const mockResponse: PaymentModeConfig = {
      paymentMode: 'Card',
      sections: [
        {
          id: 'card_config',
          title: 'Card Configuration',
          fields: [
            {
              id: 'cardSubPaymentModes',
              label: 'Select Sub Payment Mode',
              type: 'checkbox',
              options: [
                { value: 'debit', label: 'Debit Card' },
                { value: 'credit', label: 'Credit Card' },
                { value: 'prepaid', label: 'Prepaid Card' }
              ]
            },
            {
              id: 'cardRegions',
              label: 'Select Region',
              type: 'checkbox',
              options: [
                { value: 'domestic', label: 'Domestic' },
                { value: 'international', label: 'International' }
              ]
            },
            {
              id: 'cardProductTypes',
              label: 'Select Product Type',
              type: 'checkbox',
              options: [
                { value: 'standard', label: 'Standard' },
                { value: 'premium', label: 'Premium' },
                { value: 'corporate', label: 'Corporate' },
                { value: 'super_premium', label: 'Super Premium' }
              ]
            }
          ]
        }
      ]
    };
    return new Observable<PaymentModeConfig>(observer => {
      observer.next(mockResponse);
      observer.complete();
    });
  }

  /**
   * Get saved configuration for a specific merchant and payment mode
   * This returns previously saved values for the merchant
   */
  getSavedConfiguration(merchantId: string, paymentMode: string): Observable<any> {
    // return this.http.get(
    //   `${this.apiBaseUrl}/payment-configuration/${merchantId}/${paymentMode}`
    // );
    const mockResponse = localStorage.getItem(`${merchantId}_${paymentMode}`) ? JSON.parse(localStorage.getItem(`${merchantId}_${paymentMode}`)!) : {};
    return new Observable<any>(observer => {
      observer.next(mockResponse);
      observer.complete();
    });

  }

  /**
   * Save payment mode configuration for a merchant
   */
  saveConfiguration(request: SaveConfigurationRequest): Observable<SaveConfigurationResponse> {
    return this.http.post<SaveConfigurationResponse>(
      `${this.apiBaseUrl}/payment-configuration`,
      request
    );
  }

  /**
   * Update existing payment mode configuration
   */
  updateConfiguration(
    configurationId: string,
    request: SaveConfigurationRequest
  ): Observable<SaveConfigurationResponse> {
    return this.http.put<SaveConfigurationResponse>(
      `${this.apiBaseUrl}/payment-configuration/${configurationId}`,
      request
    );
  }

  /**
   * Delete payment mode configuration
   */
  deleteConfiguration(configurationId: string): Observable<SaveConfigurationResponse> {
    return this.http.delete<SaveConfigurationResponse>(
      `${this.apiBaseUrl}/payment-configuration/${configurationId}`
    );
  }
}

/**
 * API Response Examples:
 * 
 * 1. GET /api/merchants
 * [
 *   { "id": "M001", "name": "Merchant 001" },
 *   { "id": "M002", "name": "Merchant 002" }
 * ]
 * 
 * 2. GET /api/payment-modes
 * ["Card", "UPI", "Net Banking", "EMI", "FT", "Wallet"]
 * 
 * 3. GET /api/payment-mode-config/Card
 * {
 *   "paymentMode": "Card",
 *   "sections": [
 *     {
 *       "id": "card_config",
 *       "title": "Card Configuration",
 *       "fields": [
 *         {
 *           "id": "cardSubPaymentModes",
 *           "label": "Select Sub Payment Mode",
 *           "type": "checkbox",
 *           "options": [
 *             { "value": "debit", "label": "Debit Card" },
 *             { "value": "credit", "label": "Credit Card" }
 *           ]
 *         }
 *       ]
 *     }
 *   ]
 * }
 * 
 * 4. POST /api/payment-configuration
 * Request: {
 *   "merchantId": "M001",
 *   "paymentMode": "Card",
 *   "config": {
 *     "cardSubPaymentModes": ["debit", "credit"],
 *     "cardRegions": ["domestic"]
 *   }
 * }
 * Response: {
 *   "success": true,
 *   "message": "Configuration saved successfully",
 *   "configurationId": "CONFIG_12345"
 * }
 */
