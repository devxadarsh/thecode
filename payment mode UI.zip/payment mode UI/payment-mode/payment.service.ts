import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';

export interface Bank {
    id: string;
    name: string;
    isFrequent: boolean;
}

export interface Merchant {
    id: string;
    name: string;
}

export interface PaymentConfiguration {
    merchantId: string;
    paymentMode: string;
    configuration: any;
}

@Injectable({
    providedIn: 'root'
})
export class PaymentService {

    constructor() { }

    /**
     * Fetch list of merchants from backend
     * In production, replace with actual HTTP call
     */
    getMerchants(): Observable<Merchant[]> {
        const merchants: Merchant[] = [
            { id: 'M001', name: 'Amazon Payments' },
            { id: 'M002', name: 'Flipkart Commerce' },
            { id: 'M003', name: 'Paytm Mall' },
            { id: 'M004', name: 'PhonePe Merchant' },
            { id: 'M005', name: 'Google Pay Business' }
        ];

        // Simulate API delay
        return of(merchants).pipe(delay(300));
    }

    /**
     * Fetch list of banks from backend
     * In production, replace with actual HTTP call
     */
    getBanks(): Observable<Bank[]> {
        const banks: Bank[] = [
            // Top 10 frequent banks
            { id: 'B001', name: 'State Bank of India', isFrequent: true },
            { id: 'B002', name: 'HDFC Bank', isFrequent: true },
            { id: 'B003', name: 'ICICI Bank', isFrequent: true },
            { id: 'B004', name: 'Axis Bank', isFrequent: true },
            { id: 'B005', name: 'Kotak Mahindra Bank', isFrequent: true },
            { id: 'B006', name: 'Punjab National Bank', isFrequent: true },
            { id: 'B007', name: 'Bank of Baroda', isFrequent: true },
            { id: 'B008', name: 'Canara Bank', isFrequent: true },
            { id: 'B009', name: 'IDBI Bank', isFrequent: true },
            { id: 'B010', name: 'Yes Bank', isFrequent: true },

            // Other banks
            { id: 'B011', name: 'IndusInd Bank', isFrequent: false },
            { id: 'B012', name: 'Federal Bank', isFrequent: false },
            { id: 'B013', name: 'IDFC First Bank', isFrequent: false },
            { id: 'B014', name: 'RBL Bank', isFrequent: false },
            { id: 'B015', name: 'Bank of India', isFrequent: false },
            { id: 'B016', name: 'Union Bank of India', isFrequent: false },
            { id: 'B017', name: 'Indian Bank', isFrequent: false },
            { id: 'B018', name: 'Central Bank of India', isFrequent: false },
            { id: 'B019', name: 'Indian Overseas Bank', isFrequent: false },
            { id: 'B020', name: 'UCO Bank', isFrequent: false }
        ];

        // Simulate API delay
        return of(banks).pipe(delay(300));
    }

    /**
     * Save payment configuration to backend
     * In production, replace with actual HTTP POST call
     */
    saveConfiguration(config: PaymentConfiguration): Observable<any> {
        console.log('🚀 Saving configuration to backend:', config);

        // Simulate API call
        return of({
            success: true,
            message: 'Configuration saved successfully',
            id: 'CONFIG_' + Date.now()
        }).pipe(delay(500));
    }

    /**
     * Get recent configurations from backend
     * In production, replace with actual HTTP GET call
     */
    getRecentConfigurations(merchantId?: string): Observable<any[]> {
        // In production, fetch from backend
        // For now, return from localStorage
        const saved = localStorage.getItem('recentConfigurations');
        const configs = saved ? JSON.parse(saved) : [];

        return of(configs).pipe(delay(300));
    }

    /**
     * Delete a configuration
     * In production, replace with actual HTTP DELETE call
     */
    deleteConfiguration(configId: string): Observable<any> {
        console.log('🗑️ Deleting configuration:', configId);

        return of({
            success: true,
            message: 'Configuration deleted successfully'
        }).pipe(delay(300));
    }
}