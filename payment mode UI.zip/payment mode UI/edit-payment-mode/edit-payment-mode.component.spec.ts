import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPaymentModeComponent } from './edit-payment-mode.component';

describe('EditPaymentModeComponent', () => {
  let component: EditPaymentModeComponent;
  let fixture: ComponentFixture<EditPaymentModeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EditPaymentModeComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditPaymentModeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
